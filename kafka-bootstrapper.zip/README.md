# Repositorio de Configuración para Topicos y Usuarios de KAFKA

Este repositorio almacena las configuraciones y manifiestos YAML necesarios para gestionar usuarios y tópicos de Kafka en OpenShift Container Platform (OCP).

## Contenido del Repositorio

El repositorio se organiza de la siguiente manera:

- `/ambiente/nombre-del-servicio/`
  - `users/`: Contiene los archivos YAML para la creación de usuarios Kafka.
  - `topics/`: Contiene los archivos YAML para la definición de tópicos Kafka.

## Creación de Usuarios Kafka

Para crear usuarios Kafka, sigue estos pasos:

1. Crea un archivo YAML llamado `kafkaUser.yaml` en la carpeta `/nombre-del-servicio/users/`.

2. Copia y pega el contenido de este ejemplo y personalízalo con el nombre de usuario y los permisos necesarios.

```yaml
apiVersion: kafka.strimzi.io/v1beta2  # Versión de la API de Strimzi para KafkaUser.
kind: KafkaUser  # Define que estamos creando un recurso de tipo KafkaUser.

metadata:  # Información sobre el recurso, como metadatos.
  labels:  # Etiquetas asociadas al recurso.
    strimzi.io/cluster: kafka-dqh  # Etiqueta que identifica el clúster de Kafka asociado.
  name: mi-kafkaUser  # Nombre del KafkaUser.
  namespace: link-kafka-dqh  # El espacio de nombres en el que se crea este KafkaUser.

spec:  # Especificación del KafkaUser.
  authentication:
    type: scram-sha-512  # Tipo de autenticación, en este caso, se utiliza el método scram-sha-512.

  authorization:
    acls:  # Lista de control de acceso (ACL) que define las reglas de autorización.
      - host: "*"  # Se permite el acceso desde cualquier host (asterisco).
        operations:  # Operaciones permitidas en el recurso.
          - Describe  # Se permite la operación de descripción.
          - Read  # Se permite la operación de lectura.
        resource:  # Recurso al que se aplican estas ACL.
          name: nombre-miRecurso  # Nombre del recurso, en este caso, un tema Kafka.
          patternType: literal  # Tipo de patrón utilizado para el recurso (literal).
          type: topic  # El recurso es un tema Kafka.

      - host: "*"  # Nueva regla para otro recurso (grupo Kafka).
        operations:
          - Read
        resource:
          name: nombre-miGrupo  # Nombre del grupo Kafka.
          patternType: literal
          type: group  # El recurso es un grupo Kafka.

    type: simple  # Tipo de autorización, en este caso, se utiliza el método simple.
```
3. Sube el archivo `kafkaUser.yaml` al repositorio.

## Definición de Tópicos Kafka

Para definir tópicos Kafka, sigue estos pasos:

1. Crea un archivo YAML llamado `kafka-topic.yaml` en la carpeta `/nombre-del-servicio/topics/`.

2. Copia y pega el contenido de este ejemplo y personalízalo con el nombre del tópico y la configuración de particiones y réplicas.
```yaml
apiVersion: kafka.strimzi.io/v1beta2  # Versión de la API de Strimzi para KafkaTopic.
kind: KafkaTopic  # Define que estamos creando un recurso de tipo KafkaTopic.

metadata:  # Información sobre el recurso, como metadatos.
  labels:  # Etiquetas asociadas al recurso.
    strimzi.io/cluster: kafka-dqh  # Etiqueta que identifica el clúster de Kafka asociado.
  name: nombre-kafkaTopic  # Nombre del KafkaTopic.
  namespace: link-kafka-dqh  # El espacio de nombres en el que se crea este KafkaTopic.

spec:  # Especificación del KafkaTopic.
  config:  # Configuración específica del tema.
    retention.ms: 604800000  # Retención del mensaje en milisegundos, en este caso, 604,800,000 ms (una semana).
    segment.bytes: 1073741824  # Tamaño máximo del segmento en bytes, en este caso, 1,073,741,824 bytes (1 GB).
  partitions: 3  # Número de particiones para el tema, en este caso, 3 particiones.
  replicas: 3  # Número de réplicas para el tema, en este caso, 3 réplicas.

```

3. Sube el archivo `kafka-topic.yaml` al repositorio.

Recuerda que estos manifiestos YAML se utilizarán en OpenShift Container Platform para administrar usuarios y tópicos Kafka de una aplicación.

## Documentación Adicional

Para obtener más información sobre cómo gestionar usuarios y tópicos Kafka en OCP, consulta la documentación oficial:

- [Documentación de Kafka Users](https://access.redhat.com/documentation/en-us/red_hat_amq/7.2/html/using_amq_streams_on_openshift_container_platform/assembly-using-the-user-operator-str)
- [Documentación de Kafka Topics](https://access.redhat.com/documentation/en-us/red_hat_amq/7.2/html/using_amq_streams_on_openshift_container_platform/getting-started-str#what-the-topic-operator-does-str)
